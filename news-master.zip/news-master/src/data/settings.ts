export const LAYOUTS = ["list", "th", "newspaper-o", "picture-o"];
export const LIMITS = ["12", "24", "48", "96"];
export const SORTING = [
  "hot",
  "new",
  "rising",
  "controversial",
  "top",
  "gilded"
];
export const TIMES = ["year", "month", "week", "day", "hour"];
